package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

private val Background = Color(0xFF050B16)
private val Cyan = Color(0xFF28C8FF)
private val Blue = Color(0xFF087DCE)
private val Muted = Color(0xFF8297AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
fun JarvisApp() {
    var selectedTab by remember { mutableStateOf("HOME") }
    var micActive by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Background, surface = Color(0xFF101B2B))) {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF10243B), Background, Color(0xFF030811))))
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(24.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("● OFFLINE MODE", color = Color(0xFF50DDA1), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("BETA UI PREVIEW", color = Muted, fontSize = 9.sp)
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        when (selectedTab) {
                            "HOME" -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("GOOD EVENING, SIR", color = Muted, fontSize = 12.sp, letterSpacing = 3.sp)
                                Spacer(Modifier.height(24.dp))
                                Reactor()
                                Spacer(Modifier.height(24.dp))
                                Text(if (micActive) "MIC BUTTON SELECTED" else "JARVIS IS STANDBY", color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(if (micActive) "Voice recognition is not included in this beta yet" else "Awaiting your command", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                                Spacer(Modifier.height(26.dp))
                                Box(
                                    Modifier.size(76.dp).clip(CircleShape)
                                        .background(Brush.radialGradient(listOf(Color(0xFF176EA6), Color(0xFF091D32))))
                                        .border(2.dp, Cyan, CircleShape)
                                        .clickable { micActive = !micActive },
                                    contentAlignment = Alignment.Center
                                ) { Text("🎙", fontSize = 30.sp) }
                                Spacer(Modifier.height(10.dp))
                                Text("TAP TO ${if (micActive) "STOP" else "SPEAK"}", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                            }
                            "TASKS" -> PlaceholderScreen("PRODUCTIVITY", "Notes • Reminders • Timers")
                            "SYSTEM" -> PlaceholderScreen("SYSTEM CONTROL", "Phone • Music • Applications")
                            else -> PlaceholderScreen("JARVIS SETTINGS", "Voice • Appearance • Privacy")
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(bottom = 22.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        NavItem("⌂", "HOME", selectedTab) { selectedTab = "HOME" }
                        NavItem("▤", "TASKS", selectedTab) { selectedTab = "TASKS" }
                        NavItem("◈", "SYSTEM", selectedTab) { selectedTab = "SYSTEM" }
                        NavItem("⚙", "SETTINGS", selectedTab) { selectedTab = "SETTINGS" }
                    }
                }
            }
        }
    }
}

@Composable
fun Reactor() {
    val transition = rememberInfiniteTransition(label = "reactor")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "rotation")
    val pulse by transition.animateFloat(0.88f, 1.05f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")

    Canvas(Modifier.size(250.dp)) {
        val c = center
        val r = size.minDimension * 0.40f
        drawCircle(Blue.copy(alpha = 0.35f), r * 1.35f, c, style = Stroke(2.dp.toPx()))
        drawCircle(Cyan.copy(alpha = 0.5f), r * pulse, c, style = Stroke(3.dp.toPx()))
        rotate(rotation, c) {
            drawArc(Cyan, 0f, 95f, false, Offset(c.x - r * 1.2f, c.y - r * 1.2f), Size(r * 2.4f, r * 2.4f), style = Stroke(5.dp.toPx()))
            drawArc(Blue, 180f, 115f, false, Offset(c.x - r * 1.1f, c.y - r * 1.1f), Size(r * 2.2f, r * 2.2f), style = Stroke(4.dp.toPx()))
        }
        drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Blue, Color.Transparent), c, r * pulse), r * 0.72f, c)
        drawCircle(Color.White.copy(alpha = 0.8f), r * 0.22f, c)
    }
}

@Composable
fun PlaceholderScreen(title: String, description: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(description, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Text("MODULE UNDER DEVELOPMENT", color = Blue, fontSize = 10.sp)
    }
}

@Composable
fun NavItem(symbol: String, label: String, selected: String, onClick: () -> Unit) {
    val active = selected == label
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(horizontal = 9.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(symbol, color = if (active) Cyan else Muted, fontSize = 23.sp)
        Text(label, color = if (active) Cyan else Muted, fontSize = 9.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}
